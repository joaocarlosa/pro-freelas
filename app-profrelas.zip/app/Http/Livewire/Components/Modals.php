<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class Modals extends Component
{
    public function render()
    {
        return view('components.modals');
    }
}
