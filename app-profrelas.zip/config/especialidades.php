<?php

return
    [
        'Desenvolvedor front-end',
        'Desenvolvedor back-end',
        'Desenvolvedor full stack',
        'Mobile developer',
        'Developer',
        'Ca automation',
        'Data enginer',
        'Tech lead',
    ];
