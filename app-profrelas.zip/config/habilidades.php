<?php

return [
    'Design Grafico',
    'Adobe illustrator',
    'Java script',
    'Escrito de Artigos',
    'Mysql',
    'Adobe photoshop',
    'Wordpress',
    'Php',
    'Html',
    'Flutter',
    'Python',
    'Api',
];
