<?php echo e($slot); ?>

<?php /**PATH /home/u186709281/domains/profreelas.com/public_html/app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>