(function($) {
    "use strict";
    
    // Mega menu button
    $('.dropdown-mega-menu-toggle').closest('.menu-item').addClass('megamenu menu-item-has-children');

})(jQuery);